Corner Market - Supermarket & Delivery Simulator (Godot 3.6)

Run: double-click CornerMarket.exe

Controls
  WASD          move / drive the scooter
  Mouse         look around
  E             interact (pick up box, cashier, packing table, deliver)
  Left click    stock a shelf with the box in your hands / place furniture
  Q             return the box to storage
  Tab or T      tablet (order stock, prices, delivery, staff, build, report)
  F             ride / leave the scooter
  R             rotate furniture while placing
  Space         scooter brake
  Esc           menu (save, settings, quality)

How to play
  1. Open the tablet (Tab) and buy boxes. They appear in the yellow storage area.
  2. Pick up a box (E) and left-click a shelf section of the right type
     (shelf / fridge / freezer / produce stand).
  3. Customers come in at 08:00. Serve them at the cashier (E), scan, give change.
  4. Accept delivery orders on the tablet, pack them at the packing table,
     ride the scooter (F) to the yellow marker and press E.
  5. Earn money, hire staff, buy more shelves and expand the store.

Save files: %APPDATA%\Godot\app_userdata\Corner Market\
If the screen is black or the game does not start, update the graphics driver.
The game falls back to OpenGL ES 2 automatically on older graphics cards.
