@echo off
set AF_DIAG=1
start "" "%~dp0AlamAlFayoum.exe"
