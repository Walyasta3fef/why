@echo off
set AF_RENDERER=software
start "" "%~dp0AlamAlFayoum.exe"
