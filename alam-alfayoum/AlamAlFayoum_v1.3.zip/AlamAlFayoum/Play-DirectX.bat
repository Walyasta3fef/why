@echo off
set AF_RENDERER=dx9
start "" "%~dp0AlamAlFayoum.exe"
