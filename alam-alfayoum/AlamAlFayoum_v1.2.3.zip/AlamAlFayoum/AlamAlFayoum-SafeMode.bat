@echo off
cd /d "%~dp0"
start "" "AlamAlFayoum.exe" --safe
