@echo off
cd /d "%~dp0"
set AF_RENDERER=software
start "" "AlamAlFayoum.exe" --safe
